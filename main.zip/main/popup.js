// Tab switching logic
const tabs = document.querySelectorAll('.tab');
const tabContents = document.querySelectorAll('.tab-content');
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    tabContents.forEach(tc => tc.style.display = 'none');
    document.getElementById('tab-' + tab.dataset.tab).style.display = '';
  });
});

// Get current tab URL and analyze
function analyzeCurrentSite() {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    const url = tabs[0].url;
    document.getElementById('current-url').textContent = url;

    // --- VirusTotal API ---
    let virustotalResult = 'Pending';
    let dangerLevelSaved = false; // Prevent double-saving
    fetch('https://www.virustotal.com/api/v3/urls', {
      method: 'POST',
      headers: {
        'x-apikey': '30f0e4133d1f93049cd9f4f8508dab4bf00c94c3c07f0feb7aac613be9378b06',
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: 'url=' + encodeURIComponent(url)
    })
    .then(response => response.json())
    .then(data => {
      const id = data.data.id;
      return fetch('https://www.virustotal.com/api/v3/analyses/' + id, {
        headers: { 'x-apikey': '30f0e4133d1f93049cd9f4f8508dab4bf00c94c3c07f0feb7aac613be9378b06' }
      });
    })
    .then(response => response.json())
    .then(data => {
      // Heuristic: if any engine says malicious, set to Max Danger, else Safe
      let stats = data.data.attributes.stats;
      if (stats.malicious > 0) virustotalResult = 'Max Danger';
      else virustotalResult = 'Safe';
      document.getElementById('virustotal-value').textContent = virustotalResult;
      updateDangerLevel();
    })
    .catch(() => {
      virustotalResult = 'Error';
      document.getElementById('virustotal-value').textContent = 'Error';
      updateDangerLevel();
    });

    // --- Google Safe Browsing API ---
    let safebrowsingResult = 'Pending';
    fetch('https://safebrowsing.googleapis.com/v4/threatMatches:find?key=AIzaSyCxb4UqyiZ-lMILGStuwXcj9-flACLd20U', {
      method: 'POST',
      body: JSON.stringify({
        client: { clientId: 'scanner-extension', clientVersion: '1.0' },
        threatInfo: {
          threatTypes: ['MALWARE', 'SOCIAL_ENGINEERING', 'UNWANTED_SOFTWARE', 'POTENTIALLY_HARMFUL_APPLICATION'],
          platformTypes: ['ANY_PLATFORM'],
          threatEntryTypes: ['URL'],
          threatEntries: [{ url }]
        }
      }),
      headers: { 'Content-Type': 'application/json' }
    })
    .then(response => response.json())
    .then(data => {
      if (data && data.matches && data.matches.length > 0) safebrowsingResult = 'Max Danger';
      else safebrowsingResult = 'Safe';
      document.getElementById('safebrowsing-value').textContent = safebrowsingResult;
      updateDangerLevel();
    })
    .catch(() => {
      safebrowsingResult = 'Error';
      document.getElementById('safebrowsing-value').textContent = 'Error';
      updateDangerLevel();
    });

    // --- DOM Analysis ---
    chrome.scripting.executeScript({
      target: {tabId: tabs[0].id},
      func: () => {
        // Login form detection
        const loginForm = !!document.querySelector('input[type="password"]');
        // Sensitive keywords
        const keywords = ['password', 'credit card', 'ssn', 'login'];
        const bodyText = document.body.innerText.toLowerCase();
        const foundKeywords = keywords.filter(k => bodyText.includes(k));
        // Suspicious domains (simple demo)
        const suspiciousDomains = ['free', 'bonus', 'prize'];
        const foundSuspicious = suspiciousDomains.filter(k => bodyText.includes(k));
        // External links in forms
        let externalLinks = false;
        document.querySelectorAll('form').forEach(form => {
          form.querySelectorAll('a').forEach(a => {
            if (a.hostname && a.hostname !== location.hostname) externalLinks = true;
          });
        });

        // --- Enhanced DOM Analysis ---
        // 1. Hidden iframes, overlays, and suspiciously hidden elements
        let hiddenIframes = 0;
        let overlays = 0;
        let hiddenElements = 0;
        document.querySelectorAll('iframe').forEach(iframe => {
          const style = window.getComputedStyle(iframe);
          if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') hiddenIframes++;
        });
        document.querySelectorAll('*').forEach(el => {
          const style = window.getComputedStyle(el);
          if ((style.position === 'fixed' || style.position === 'absolute') && style.zIndex && parseInt(style.zIndex) > 1000 && style.opacity > 0.7 && el.offsetHeight > 100 && el.offsetWidth > 100) overlays++;
          if ((style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') && el.offsetParent !== null) hiddenElements++;
        });

        // 2. Anchor tag analysis for mismatched text/href and lookalike domains
        function looksLikeDomain(text) {
          return /([a-z0-9\-]+\.)+[a-z]{2,}/i.test(text);
        }
        function isLookalikeDomain(domain, href) {
          // Simple check: replace 0 with o, 1 with l, etc.
          const normalized = domain.replace(/[01]/g, c => c === '0' ? 'o' : 'l');
          return href.includes(normalized) === false && href.includes(domain) === false;
        }
        let mismatchedAnchors = 0;
        let lookalikeAnchors = 0;
        document.querySelectorAll('a').forEach(a => {
          const text = (a.textContent || '').trim();
          const href = a.href || '';
          if (looksLikeDomain(text) && href && !href.includes(text)) mismatchedAnchors++;
          // Lookalike domain check
          if (looksLikeDomain(text) && href) {
            const domain = text.match(/([a-z0-9\-]+\.)+[a-z]{2,}/i);
            if (domain && isLookalikeDomain(domain[0], href)) lookalikeAnchors++;
          }
        });

        // 3. Suspicious form actions (different domain, autocomplete off)
        let suspiciousFormActions = 0;
        document.querySelectorAll('form').forEach(form => {
          const action = form.action || '';
          if (action && action.indexOf(location.hostname) === -1 && action !== '') suspiciousFormActions++;
          if (form.autocomplete === 'off') suspiciousFormActions++;
        });

        // 4. Suspicious scripts (obfuscated, eval, base64)
        let suspiciousScripts = 0;
        document.querySelectorAll('script').forEach(script => {
          const src = script.src || '';
          const text = script.textContent || '';
          if (/eval\s*\(/.test(text) || /atob\s*\(/.test(text) || /fromCharCode/.test(text) || /base64/i.test(text)) suspiciousScripts++;
        });

        // 5. MutationObserver for dynamic content (throttled summary)
        // (This is a one-time scan, but you could inject a MutationObserver for live monitoring)

        // Summarize suspicious elements
        const suspiciousElements =
          hiddenIframes > 0 || overlays > 0 || hiddenElements > 2 || mismatchedAnchors > 0 || lookalikeAnchors > 0 || suspiciousFormActions > 0 || suspiciousScripts > 0;

        return {
          loginForm,
          foundKeywords,
          foundSuspicious,
          externalLinks,
          suspiciousElements,
          details: {
            hiddenIframes,
            overlays,
            hiddenElements,
            mismatchedAnchors,
            lookalikeAnchors,
            suspiciousFormActions,
            suspiciousScripts
          }
        };
      }
    }, (results) => {
      if (results && results[0] && results[0].result) {
        const r = results[0].result;
        document.getElementById('dom-login').textContent = r.loginForm ? 'Detected' : 'Not detected';
        document.getElementById('dom-keywords').textContent = r.foundKeywords.length ? r.foundKeywords.join(', ') : 'Not detected';
        document.getElementById('dom-suspicious-domains').textContent = r.foundSuspicious.length ? r.foundSuspicious.join(', ') : 'Not detected';
        document.getElementById('dom-external-links').textContent = r.externalLinks ? 'Detected' : 'Not detected';
        // Improved clarity for suspicious elements
        const suspiciousText = r.suspiciousElements ? 'Yes' : 'No';
        let detailsText = '';
        if (Object.values(r.details).some(v => v > 0)) {
          detailsText = Object.entries(r.details)
            .map(([k, v]) => `${k}: ${v}`)
            .join(', ');
        }
        // Only set the value, not the label, to avoid double label
        document.getElementById('dom-suspicious-elements').textContent = suspiciousText + (detailsText ? ` | Details: ${detailsText}` : '');
      }
    });

    // --- Danger Level ---
    function updateDangerLevel() {
      let level = 'Safe';
      if (virustotalResult === 'Max Danger' || safebrowsingResult === 'Max Danger') level = 'Max Danger';
      else if (virustotalResult === 'Warning' || safebrowsingResult === 'Warning') level = 'Warning';
      document.getElementById('danger-level-value').textContent = level;
      // Only save to history once, when both results are not 'Pending' and not already saved
      if (!dangerLevelSaved && virustotalResult !== 'Pending' && safebrowsingResult !== 'Pending') {
        saveToHistory(url, level);
        renderHistory();
        dangerLevelSaved = true;
      }
    }
  });
}
analyzeCurrentSite();

// Check URL tab logic
const checkBtn = document.getElementById('check-url-btn');
if (checkBtn) {
  checkBtn.addEventListener('click', () => {
    const input = document.getElementById('check-url-input').value;
    if (!input) return;
    document.getElementById('check-url-result').textContent = 'Analyzing URL...';
    // Reset fields
    document.getElementById('checkurl-danger-level-value').textContent = '-';
    document.getElementById('checkurl-virustotal-value').textContent = '-';
    document.getElementById('checkurl-safebrowsing-value').textContent = '-';
    document.getElementById('checkurl-dom-login').textContent = '-';
    document.getElementById('checkurl-dom-keywords').textContent = '-';
    document.getElementById('checkurl-dom-suspicious-domains').textContent = '-';
    document.getElementById('checkurl-dom-external-links').textContent = '-';
    document.getElementById('checkurl-dom-suspicious-elements').textContent = '-';

    let virustotalResult = 'Pending';
    let safebrowsingResult = 'Pending';
    let dangerLevelSaved = false; // Prevent double-saving

    // --- VirusTotal API ---
    fetch('https://www.virustotal.com/api/v3/urls', {
      method: 'POST',
      headers: {
        'x-apikey': '30f0e4133d1f93049cd9f4f8508dab4bf00c94c3c07f0feb7aac613be9378b06',
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: 'url=' + encodeURIComponent(input)
    })
    .then(response => response.json())
    .then(data => {
      const id = data.data.id;
      return fetch('https://www.virustotal.com/api/v3/analyses/' + id, {
        headers: { 'x-apikey': '30f0e4133d1f93049cd9f4f8508dab4bf00c94c3c07f0feb7aac613be9378b06' }
      });
    })
    .then(response => response.json())
    .then(data => {
      let stats = data.data.attributes.stats;
      if (stats.malicious > 0) virustotalResult = 'Max Danger';
      else if (stats.suspicious > 0) virustotalResult = 'Warning';
      else virustotalResult = 'Safe';
      document.getElementById('checkurl-virustotal-value').textContent = virustotalResult;
      updateCheckUrlDangerLevel();
    })
    .catch(() => {
      virustotalResult = 'Error';
      document.getElementById('checkurl-virustotal-value').textContent = 'Error';
      updateCheckUrlDangerLevel();
    });

    // --- Google Safe Browsing API ---
    fetch('https://safebrowsing.googleapis.com/v4/threatMatches:find?key=AIzaSyCxb4UqyiZ-lMILGStuwXcj9-flACLd20U', {
      method: 'POST',
      body: JSON.stringify({
        client: { clientId: 'scanner-extension', clientVersion: '1.0' },
        threatInfo: {
          threatTypes: ['MALWARE', 'SOCIAL_ENGINEERING', 'UNWANTED_SOFTWARE', 'POTENTIALLY_HARMFUL_APPLICATION'],
          platformTypes: ['ANY_PLATFORM'],
          threatEntryTypes: ['URL'],
          threatEntries: [{ url: input }]
        }
      }),
      headers: { 'Content-Type': 'application/json' }
    })
    .then(response => response.json())
    .then(data => {
      if (data && data.matches && data.matches.length > 0) safebrowsingResult = 'Max Danger';
      else safebrowsingResult = 'Safe';
      document.getElementById('checkurl-safebrowsing-value').textContent = safebrowsingResult;
      updateCheckUrlDangerLevel();
    })
    .catch(() => {
      safebrowsingResult = 'Error';
      document.getElementById('checkurl-safebrowsing-value').textContent = 'Error';
      updateCheckUrlDangerLevel();
    });

    // --- DOM Analysis (for remote URLs, not possible directly) ---
    fetch(input)
      .then(response => response.text())
      .then(html => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        // Login form detection
        const loginForm = !!doc.querySelector('input[type="password"]');
        // Sensitive keywords
        const keywords = ['password', 'credit card', 'ssn', 'login'];
        const bodyText = (doc.body ? doc.body.innerText : '').toLowerCase();
        const foundKeywords = keywords.filter(k => bodyText.includes(k));
        // Suspicious domains (simple demo)
        const suspiciousDomains = ['free', 'bonus', 'prize'];
        const foundSuspicious = suspiciousDomains.filter(k => bodyText.includes(k));
        // External links in forms
        let externalLinks = false;
        doc.querySelectorAll('form').forEach(form => {
          form.querySelectorAll('a').forEach(a => {
            if (a.hostname && a.hostname !== (new URL(input)).hostname) externalLinks = true;
          });
        });
        // --- Enhanced DOM Analysis (match current site logic) ---
        let hiddenIframes = 0;
        let overlays = 0;
        let hiddenElements = 0;
        doc.querySelectorAll('iframe').forEach(iframe => {
          const style = iframe.getAttribute('style') || '';
          if (style.includes('display:none') || style.includes('visibility:hidden') || style.includes('opacity:0')) hiddenIframes++;
        });
        doc.querySelectorAll('*').forEach(el => {
          const style = el.getAttribute('style') || '';
          if ((style.includes('position:fixed') || style.includes('position:absolute')) && style.includes('z-index:') && style.includes('opacity:')) overlays++;
          if (style.includes('display:none') || style.includes('visibility:hidden') || style.includes('opacity:0')) hiddenElements++;
        });
        // Anchor tag analysis for mismatched text/href and lookalike domains
        function looksLikeDomain(text) {
          return /([a-z0-9\-]+\.)+[a-z]{2,}/i.test(text);
        }
        function isLookalikeDomain(domain, href) {
          const normalized = domain.replace(/[01]/g, c => c === '0' ? 'o' : 'l');
          return href.includes(normalized) === false && href.includes(domain) === false;
        }
        let mismatchedAnchors = 0;
        let lookalikeAnchors = 0;
        doc.querySelectorAll('a').forEach(a => {
          const text = (a.textContent || '').trim();
          const href = a.href || '';
          if (looksLikeDomain(text) && href && !href.includes(text)) mismatchedAnchors++;
          if (looksLikeDomain(text) && href) {
            const domain = text.match(/([a-z0-9\-]+\.)+[a-z]{2,}/i);
            if (domain && isLookalikeDomain(domain[0], href)) lookalikeAnchors++;
          }
        });
        // Suspicious form actions
        let suspiciousFormActions = 0;
        doc.querySelectorAll('form').forEach(form => {
          const action = form.action || '';
          if (action && action.indexOf((new URL(input)).hostname) === -1 && action !== '') suspiciousFormActions++;
          if (form.autocomplete === 'off') suspiciousFormActions++;
        });
        // Suspicious scripts
        let suspiciousScripts = 0;
        doc.querySelectorAll('script').forEach(script => {
          const text = script.textContent || '';
          if (/eval\s*\(/.test(text) || /atob\s*\(/.test(text) || /fromCharCode/.test(text) || /base64/i.test(text)) suspiciousScripts++;
        });
        const suspiciousElements =
          hiddenIframes > 0 || overlays > 0 || hiddenElements > 2 || mismatchedAnchors > 0 || lookalikeAnchors > 0 || suspiciousFormActions > 0 || suspiciousScripts > 0;
        // Update DOM analysis fields (match current site style)
        document.getElementById('checkurl-dom-login').textContent = loginForm ? t('detected') : t('notDetected');
        document.getElementById('checkurl-dom-keywords').textContent = foundKeywords.length ? foundKeywords.join(', ') : t('notDetected');
        document.getElementById('checkurl-dom-suspicious-domains').textContent = foundSuspicious.length ? foundSuspicious.join(', ') : t('notDetected');
        document.getElementById('checkurl-dom-external-links').textContent = externalLinks ? t('detected') : t('notDetected');
        // Improved clarity for suspicious elements (Check URL tab)
        const suspiciousText = suspiciousElements ? 'Yes' : 'No';
        let detailsText = '';
        const details = {
          hiddenIframes,
          overlays,
          hiddenElements,
          mismatchedAnchors,
          lookalikeAnchors,
          suspiciousFormActions,
          suspiciousScripts
        };
        if (Object.values(details).some(v => v > 0)) {
          detailsText = Object.entries(details)
            .map(([k, v]) => `${k}: ${v}`)
            .join(', ');
        }
        // Only set the value, not the label, to avoid double label
        document.getElementById('checkurl-dom-suspicious-elements').textContent = suspiciousText + (detailsText ? ` | Details: ${detailsText}` : '');
      })
      .catch(() => {
        document.getElementById('checkurl-dom-login').textContent = t('notAvailable');
        document.getElementById('checkurl-dom-keywords').textContent = t('notAvailable');
        document.getElementById('checkurl-dom-suspicious-domains').textContent = t('notAvailable');
        document.getElementById('checkurl-dom-external-links').textContent = t('notAvailable');
        document.getElementById('checkurl-dom-suspicious-elements').textContent = t('notAvailable');
      });

    // --- Danger Level ---
    function updateCheckUrlDangerLevel() {
      let level = 'Safe';
      if (virustotalResult === 'Max Danger' || safebrowsingResult === 'Max Danger') level = 'Max Danger';
      else if (virustotalResult === 'Warning' || safebrowsingResult === 'Warning') level = 'Warning';
      document.getElementById('checkurl-danger-level-value').textContent = level;
      document.getElementById('check-url-result').textContent = '';
      // Only save to history once, when both results are not 'Pending' and not already saved
      if (!dangerLevelSaved && virustotalResult !== 'Pending' && safebrowsingResult !== 'Pending') {
        saveToHistory(input, level);
        renderHistory();
        dangerLevelSaved = true;
        // Send message to background to show banner if needed
        chrome.runtime.sendMessage({ action: 'checkAndBanner', dangerLevel: level, url: input });
      }
    }
  });
}

// On popup open, check if a scanUrl is set from context menu
chrome.storage.local.get(['scanUrl'], (result) => {
  if (result.scanUrl) {
    document.getElementById('check-url-input').value = result.scanUrl;
    document.getElementById('check-url-btn').click();
    // Switch to Check URL tab
    document.querySelector('.tab[data-tab="check"]').click();
    chrome.storage.local.remove('scanUrl');
  }
});

// History logic
function saveToHistory(url, dangerLevel) {
  const history = JSON.parse(localStorage.getItem('scanHistory') || '[]');
  history.unshift({ url, dangerLevel, date: new Date().toLocaleString() });
  localStorage.setItem('scanHistory', JSON.stringify(history.slice(0, 20)));
}

function renderHistory() {
  const history = JSON.parse(localStorage.getItem('scanHistory') || '[]');
  const list = document.getElementById('history-list');
  if (!history.length) {
    list.textContent = t('historyNone');
    return;
  }
  list.innerHTML = '<b>' + t('historyTitle') + '</b><ul style="padding-left: 16px;">' +
    history.map(item =>
      `<li style="margin-bottom: 8px;">
        <div style="word-break:break-all;">${item.url}</div>
        <div>${t('dangerLevel')} <b>${item.dangerLevel}</b></div>
        <div style="font-size:11px;color:#888;">${t('date')} ${item.date}</div>
      </li>`
    ).join('') + '</ul>';
}

document.getElementById('clear-history-btn').onclick = function() {
  localStorage.removeItem('scanHistory');
  renderHistory();
};

// Settings logic
const languageBox = document.getElementById('setting-language');
const themeBox = document.getElementById('setting-theme');
const saveBtn = document.getElementById('save-settings-btn');
const statusDiv = document.getElementById('settings-status');

// Translation dictionary
const translations = {
  en: {
    mainTitle: 'Tryscamme Scanner',
    title: 'tryscamme - Phishing Prevention',
    tabCurrent: 'Current Site',
    tabCheck: 'Check URL',
    tabHistory: 'History',
    tabSettings: 'Settings',
    analyzing: 'Analyzing:',
    dangerLevel: 'Danger Level:',
    virustotal: 'VirusTotal:',
    safebrowsing: 'Google Safe Browsing:',
    domAnalysis: 'DOM Analysis:',
    loginForm: 'Login form:',
    keywords: 'Sensitive keywords:',
    suspiciousDomains: 'Suspicious domains:',
    externalLinks: 'External links in forms:',
    suspiciousElements: 'Suspicious elements detected:',
    checking: 'Checking...',
    scanning: 'Scanning...',
    enterUrl: 'Enter URL to check',
    check: 'Check',
    historyNone: 'No history yet.',
    historyTitle: 'Recently Analyzed URLs',
    clearHistory: 'Clear History',
    settings: 'Settings',
    language: 'Language:',
    theme: 'Theme:',
    saveSettings: 'Save Settings',
    settingsSaved: 'Settings saved!',
    detected: 'Detected',
    notDetected: 'Not detected',
    notAvailable: 'Not available',
    date: 'Date:',
    analyzingUrl: 'Analyzing URL...'
  },
  ru: {
    mainTitle: 'Tryscamme Сканер',
    title: 'Tryscamme Scanner',
    tabCurrent: 'Текущий сайт',
    tabCheck: 'Проверить URL',
    tabHistory: 'История',
    tabSettings: 'Настройки',
    analyzing: 'Анализируется:',
    dangerLevel: 'Уровень опасности:',
    virustotal: 'VirusTotal:',
    safebrowsing: 'Google Safe Browsing:',
    domAnalysis: 'DOM-анализ:',
    loginForm: 'Форма входа:',
    keywords: 'Чувствительные слова:',
    suspiciousDomains: 'Подозрительные домены:',
    externalLinks: 'Внешние ссылки в формах:',
    suspiciousElements: 'Подозрительных элементов в структуре страницы не обнаружено:',
    checking: 'Проверка...',
    scanning: 'Сканирование...',
    enterUrl: 'Введите URL для проверки',
    check: 'Проверить',
    historyNone: 'История пуста.',
    historyTitle: 'Недавно проанализированные URL',
    clearHistory: 'Очистить историю',
    settings: 'Настройки',
    language: 'Язык:',
    theme: 'Тема:',
    saveSettings: 'Сохранить настройки',
    settingsSaved: 'Настройки сохранены!',
    detected: 'Обнаружено',
    notDetected: 'Не обнаружено',
    notAvailable: 'Недоступно',
    date: 'Дата:',
    analyzingUrl: 'Анализируется URL...',
    // Additional for new UI
    currentSite: 'Текущий сайт',
    checkUrl: 'Проверить URL',
    history: 'История',
    settingsTab: 'Настройки',
    loginFormDetected: 'Форма входа: Обнаружено',
    loginFormNotDetected: 'Форма входа: Не обнаружено',
    keywordsDetected: 'Чувствительные слова: ',
    keywordsNotDetected: 'Чувствительные слова: Не обнаружено',
    suspiciousDomainsDetected: 'Подозрительные домены: ',
    suspiciousDomainsNotDetected: 'Подозрительные домены: Не обнаружено',
    externalLinksDetected: 'Внешние ссылки в формах: Обнаружено',
    externalLinksNotDetected: 'Внешние ссылки в формах: Не обнаружено',
    suspiciousElementsDetected: 'Подозрительные элементы в структуре страницы: Обнаружено',
    suspiciousElementsNotDetected: 'Подозрительных элементов в структуре страницы не обнаружено',
    // Button and label translations
    save: 'Сохранить',
    close: 'Закрыть',
    dismiss: 'Скрыть',
    // Banner
    phishingAlert: 'Фишинговое предупреждение',
    // Danger levels
    Safe: 'Безопасно',
    Warning: 'Внимание',
    'Max Danger': 'Максимальная опасность',
    Error: 'Ошибка'
  }
};

function getLang() {
  const settings = JSON.parse(localStorage.getItem('protectionSettings') || '{}');
  return settings.language || 'en';
}

function t(key) {
  const lang = getLang();
  return translations[lang][key] || translations['en'][key] || key;
}

function applyTranslations() {
  // Main title
  document.getElementById('main-title').textContent = t('mainTitle');
  // Tabs
  const tabButtons = document.querySelectorAll('.tab');
  if (tabButtons.length >= 4) {
    tabButtons[0].textContent = t('tabCurrent');
    tabButtons[1].textContent = t('tabCheck');
    tabButtons[2].textContent = t('tabHistory');
    tabButtons[3].textContent = t('tabSettings');
  }
  // Current tab
  document.getElementById('current-url-label').textContent = t('analyzing');
  document.getElementById('danger-level').firstChild.textContent = t('dangerLevel') + ' ';
  document.getElementById('virustotal-result').firstChild.textContent = t('virustotal') + ' ';
  document.getElementById('safebrowsing-result').firstChild.textContent = t('safebrowsing') + ' ';
  document.getElementById('dom-analysis').firstChild.textContent = t('domAnalysis') + ' ';
  const domList = document.getElementById('dom-analysis-list').children;
  domList[0].innerHTML = t('loginForm') + ' <span id="dom-login">' + t('checking') + '</span>';
  domList[1].innerHTML = t('keywords') + ' <span id="dom-keywords">' + t('checking') + '</span>';
  domList[2].innerHTML = t('suspiciousDomains') + ' <span id="dom-suspicious-domains">' + t('checking') + '</span>';
  domList[3].innerHTML = t('externalLinks') + ' <span id="dom-external-links">' + t('checking') + '</span>';
  domList[4].innerHTML = t('suspiciousElements') + ' <span id="dom-suspicious-elements">' + t('checking') + '</span>';
  // Check tab
  document.getElementById('check-url-input').placeholder = t('enterUrl');
  document.getElementById('check-url-btn').textContent = t('check');
  document.getElementById('checkurl-danger-level').firstChild.textContent = t('dangerLevel') + ' ';
  document.getElementById('checkurl-virustotal-result').firstChild.textContent = t('virustotal') + ' ';
  document.getElementById('checkurl-safebrowsing-result').firstChild.textContent = t('safebrowsing') + ' ';
  document.getElementById('checkurl-dom-analysis').firstChild.textContent = t('domAnalysis') + ' ';
  const checkDomList = document.getElementById('checkurl-dom-analysis-list').children;
  checkDomList[0].innerHTML = t('loginForm') + ' <span id="checkurl-dom-login">-</span>';
  checkDomList[1].innerHTML = t('keywords') + ' <span id="checkurl-dom-keywords">-</span>';
  checkDomList[2].innerHTML = t('suspiciousDomains') + ' <span id="checkurl-dom-suspicious-domains">-</span>';
  checkDomList[3].innerHTML = t('externalLinks') + ' <span id="checkurl-dom-external-links">-</span>';
  checkDomList[4].innerHTML = t('suspiciousElements') + ' <span id="checkurl-dom-suspicious-elements">-</span>';
  // History tab
  document.getElementById('clear-history-btn').textContent = t('clearHistory');
  // Settings tab
  document.querySelector('label[for="setting-language"]').innerHTML = '<b>' + t('language') + '</b>';
  document.querySelector('label[for="setting-theme"]').innerHTML = '<b>' + t('theme') + '</b>';
  document.getElementById('save-settings-btn').textContent = t('saveSettings');
  // Settings title
  document.querySelector('#tab-settings > div > b').textContent = t('settings');
}

function loadSettings() {
  const settings = JSON.parse(localStorage.getItem('protectionSettings') || '{}');
  languageBox.value = settings.language || 'en';
  themeBox.value = settings.theme || 'dark';
  applyTranslations();
}

function saveSettings() {
  const settings = {
    language: languageBox.value,
    theme: themeBox.value
  };
  localStorage.setItem('protectionSettings', JSON.stringify(settings));
  statusDiv.textContent = t('settingsSaved');
  setTimeout(() => statusDiv.textContent = '', 1500);
  applyTheme();
  applyTranslations();
}

function applyTheme() {
  const theme = themeBox.value;
  document.body.classList.remove('theme-dark', 'theme-light');
  if (theme === 'dark') {
    document.body.classList.add('theme-dark');
  } else {
    document.body.classList.add('theme-light');
  }
}

if (saveBtn) saveBtn.onclick = saveSettings;
loadSettings();
applyTheme();
applyTranslations();

// Render history on popup open
renderHistory();

// Add context menu for scanning site (if available in popup context)
if (chrome.contextMenus && chrome.contextMenus.create) {
  chrome.contextMenus.create({
    id: 'scan-site',
    title: 'Scan site with tryscamme',
    contexts: ['link', 'page', 'selection']
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    let url = info.linkUrl || info.pageUrl || info.selectionText;
    if (url) {
      chrome.storage.local.set({ scanUrl: url }, () => {
        window.open(chrome.runtime.getURL('popup.html'), '_blank');
      });
    }
  });
}